#!/sbin/busybox sh

# Ketut P. Kumajaya, May 2013

if /sbin/busybox [ $(/sbin/busybox mount | /sbin/busybox grep -c "/data") -lt 1 ]; then
  /sbin/mount /data
fi

SECONDROM=1
/sbin/busybox [ -f /data/media/.secondrom/system.img ] || SECONDROM=0

exit $SECONDROM
