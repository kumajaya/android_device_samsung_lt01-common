#!/sbin/busybox sh

# Ketut P. Kumajaya: May 2013, Nov 2013, Apr 2014, Sept 2014

if /sbin/busybox [ $(/sbin/busybox mount | /sbin/busybox grep -c "/data") -lt 1 ]; then
  /sbin/mount /data
fi

if /sbin/busybox [ $(/sbin/busybox mount | /sbin/busybox grep "/system" | /sbin/busybox grep -c "loop0") -eq 1 ]; then
  /sbin/umount -d -f /system
fi

if /sbin/busybox [ $(/sbin/busybox losetup | /sbin/busybox grep "system.img" | /sbin/busybox grep -c "loop0") -eq 1 ]; then
  /sbin/busybox losetup -d /dev/block/loop0
fi

if /sbin/busybox [ -f /data/media/.secondrom/system.img ]; then
  /sbin/busybox rm -f /data/media/.secondrom/system.img
fi

/sbin/busybox mkdir -p /data/media/.secondrom
# Create 2GB sparse image
/sbin/busybox dd if=/dev/zero of=/data/media/.secondrom/system.img bs=1024 seek=2000000 count=0

if /sbin/busybox [ -f /data/media/.secondrom/system.img ]; then
  /sbin/busybox losetup /dev/block/loop0 /data/media/.secondrom/system.img
fi

# Create ext4 filesystem without a journal
if /sbin/busybox [ $(/sbin/busybox losetup -a | /sbin/busybox grep "system.img" | /sbin/busybox grep -c "loop0") -eq 1 ]; then
  /sbin/make_ext4fs -J /dev/block/loop0
  /sbin/busybox losetup -d /dev/block/loop0
fi
