#!/sbin/busybox sh

# Ketut P. Kumajaya, May 2013
# Ketut P. Kumajaya, Nov 2013

if /sbin/busybox [ $(/sbin/busybox mount | /sbin/busybox grep -c "/data") -lt 1 ]; then
  /sbin/mount /data
fi

if /sbin/busybox [ $(/sbin/busybox mount | /sbin/busybox grep "/system" | /sbin/busybox grep -c "loop0") -eq 1 ]; then
  /sbin/umount -d -f /system
fi

if /sbin/busybox [ $(/sbin/busybox losetup | /sbin/busybox grep "system.img" | /sbin/busybox grep -c "loop0") -eq 1 ]; then
  /sbin/busybox losetup -d /dev/block/loop0
fi

if /sbin/busybox [ -f /data/media/.secondrom/system.img ]; then
  /sbin/busybox rm -f /data/media/.secondrom/system.img
fi

if /sbin/busybox [ -d /data/media/.secondrom/data ]; then
  cd /data/media/.secondrom/data
  for f in $(ls -a | grep -v ^media$); do
    rm -rf $f
  done
  cd /
fi

if /sbin/busybox [ $(/sbin/busybox mount | /sbin/busybox grep "/cache" | /sbin/busybox grep -c "mmcblk0p16") -eq 1 ]; then
  /sbin/umount /cache
fi

/sbin/busybox mke2fs -T ext4 -b 4096 -m 0 -J size=16 -O ^resize_inode,^ext_attr,^huge_file /dev/block/mmcblk0p16
/sbin/busybox tune2fs -c 0 -i 0 /dev/block/mmcblk0p16

if /sbin/busybox [ $(/sbin/busybox mount | /sbin/busybox grep -c "/cache") -eq 0 ]; then
  /sbin/mount /cache
fi
